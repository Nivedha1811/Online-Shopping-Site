package com.onlineshopping.product.service;

import com.onlineshopping.product.entity.Product;
import java.util.List;

public interface ProductService {
    Product saveProduct(Product product);
    List<Product> getAllProducts();
    Product getProductById(Long id);
    boolean deleteProduct(Long id);
}
